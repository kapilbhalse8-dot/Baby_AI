BABY AI — अपडेटेड Android सोर्स प्रोजेक्ट

मौजूदा कोड/फाइलों से जो उपयोगी सुविधाएँ शामिल की गई हैं:
- Baby AI नाम की हिंदी चैट स्क्रीन
- हिंदी में बोलकर इनपुट (फोन की Speech Recognition सेवा और microphone permission पर निर्भर)
- Android Text-to-Speech; हिंदी महिला आवाज़ फोन में उपलब्ध voice पर निर्भर
- चैट इतिहास फोन के निजी स्टोरेज में सेव
- WhatsApp, YouTube और Chrome खोलने के शॉर्टकट
- ऐप खुले रहने पर 20% बैटरी पर एक बार आवाज़ की चेतावनी
- नया “AI फाइल जोड़ें” बटन: फोन से फाइल चुनता है और उसका नाम/URI ऐप में सेव रखता है

महत्वपूर्ण सीमाएँ:
- यह Android Studio सोर्स प्रोजेक्ट है, APK नहीं।
- चुनी हुई AI फाइल अभी केवल ऐप से लिंक/सेव होती है। उसे AI मॉडल की तरह चलाने के लिए
  फाइल का सटीक फॉर्मेट (जैसे TFLite/ONNX/अन्य) और उसी के अनुरूप inference runtime,
  मॉडल की input/output जानकारी तथा preprocessing जोड़ना जरूरी है।
- इस प्रोजेक्ट में ChatGPT-जैसा ऑनलाइन AI backend/API अभी नहीं है।
- महिला आवाज़ की गारंटी नहीं; यह फोन के installed Hindi TTS engine/voice पर निर्भर है।
- 2 मिनट lock/unlock greeting और face recognition मूल फाइलों में भी लागू नहीं थे,
  इसलिए उन्हें शामिल/दावा नहीं किया गया।
- Android SDK/Gradle build environment इस रनटाइम में उपलब्ध नहीं है; APK build और
  device testing यहाँ नहीं की जा सकी।

APK बनाने के लिए:
1. Android Studio में यह पूरा project folder खोलें।
2. Android SDK Platform 35 और Android Gradle Plugin install/sync करें।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. Debug APK app/build/outputs/apk/debug/app-debug.apk में बनेगी।
